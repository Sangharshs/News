package com.example.sarkaribook.Retrofit;

public class ApiUtils {

    public static final String MAIN_URL = "http://adminapp.tech/learners/";
    public static final String BASE_URL = MAIN_URL+"api/";
    public static final String M_URL = "http://adminapp.tech";

}
