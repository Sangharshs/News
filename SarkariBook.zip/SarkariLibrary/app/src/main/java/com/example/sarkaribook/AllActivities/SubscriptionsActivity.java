package com.example.sarkaribook.AllActivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.sarkaribook.Adapter.SubscriptionPlanAdapter;
import com.example.sarkaribook.Model.Subscription;
import com.example.sarkaribook.R;

import java.util.ArrayList;
import java.util.List;

public class SubscriptionsActivity extends AppCompatActivity {

    RecyclerView subscriptionRecyclerView;
    List<Subscription> subscriptionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscriptions);

        subscriptionRecyclerView = findViewById(R.id.subscriptionsPlansRecyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        subscriptionRecyclerView.setLayoutManager(linearLayoutManager);

        subscriptionList = new ArrayList<>();

        subscriptionList.add(new Subscription("Buy For 30 Days","In Just Rs 99"));
        subscriptionList.add(new Subscription("Buy For 60 Days", "In Just Rs 199"));
        subscriptionList.add(new Subscription("Buy For 120 Days","In Just Rs 299"));
        subscriptionList.add(new Subscription("Buy For 180 Days","In Just Rs 399"));

        SubscriptionPlanAdapter adapter = new SubscriptionPlanAdapter(subscriptionList,this);
        subscriptionRecyclerView.setAdapter(adapter);


    }
}